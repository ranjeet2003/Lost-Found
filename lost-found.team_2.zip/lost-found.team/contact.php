<?php
    if(isset($_POST['send'])){
        include('dbcon.php');
        $username=$_POST['name'];
        $sub=$_POST['subject'];
        $email=$_POST['email'];
        $msg=$_POST['message'];
        $qry="INSERT INTO `contactus`(`name`, `email`, `subject`, `message`) VALUES ('$username','$email','$sub','$msg')";
        $run=mysqli_query($con,$qry);
        if($run==true){
            
            header('location:index.php?msgsent=success');
        }
    }
?>