<?php
    $con=mysqli_connect('fdb23.awardspace.net','3421201_lostfounddetails','Ranjeet2003','3421201_lostfounddetails');
    if($con==false){
        echo "connection is not done";
    }
?>