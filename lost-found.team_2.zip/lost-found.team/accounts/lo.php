<?php
        
        if(isset($_POST['upload'])){
            include('../dbcon.php');
            $name=$_SESSION['username'];
            $dname=$_POST['dname'];
            $dserial=$_POST['serial'];
            $descrp=$_POST['Description'];
            $imagename=$_FILES['simg']['name'];
            $tempname=$_FILES['simg']['tmp_name'];
            move_uploaded_file($tempname,"lost_img/$imagename");
            $qry="INSERT INTO `lost_info`(`uname`,`dname`, `dserialno`, `descrp`, `img`) VALUES ('$name','$dname','$dserial','$descrp','$imagename')";
            $run=mysqli_query($con,$qry);
            if($run==true){
                header('location:../welcome.php?status=success');
            }
            else{
                echo "something went wrong";
            }
            
            
           
        }
?>