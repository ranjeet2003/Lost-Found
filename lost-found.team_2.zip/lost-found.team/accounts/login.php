<?php
    include('../dbcon.php');
    if(isset($_POST['login'])){
        $email=$_POST['email'];
        $password=$_POST['password'];
        //$hash=md5($password);
        $qry="SELECT * FROM `info` WHERE `Email`='$email' AND `password`='$password'";
        $run=mysqli_query($con,$qry);
        $qry1="SELECT `uname` FROM `info` WHERE `Email`='$email' AND `password`='$password'";
        $row=mysqli_num_rows($run);
        $run1=mysqli_query($con,$qry1);
        $data = mysqli_fetch_assoc($run1);
        //$row1=mysqli_num_rows($run1);
        if($row<1){
            ?>
            <script>
                alert('Username or Password is incorrect !');
                window.open('login.php','_self');
            </script>

            <?php
        }
        else{
            session_start();
            $_SESSION['username']=$data['uname'];
            // echo "Hello";
            header('location:../welcome.php');
        }
    }
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Login</title>

    <link rel="shortcut icon" href="assets/images/fav.jpg">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawsom-all.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
</head>

<body>
    <div class="container-fluid ">
        <div class="container ">
            <div class="row ">
                <div class="col-sm-10 login-box">
                    <div class="row">
                        <div class="col-lg-8 col-md-7 log-det">
                            
                            <h2>Lost-Found</h2>
                            <div class="row">
                                <ul>
                                    <li><i class="fab fa-facebook-f"></i></li>
                                    <li><i class="fab fa-twitter"></i></li>
                                    <li><i class="fab fa-linkedin-in"></i></li>
                                </ul>
                            </div>
                            <div class="row">
                                <p class="small-info">or use your email account</p>
                            </div>

                        <form method="post">
                            <div class="text-box-cont">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-envelope"></i></span>
                                    </div>
                                    <input type="email" class="form-control" placeholder="E-Mail" aria-label="E-Mail" aria-describedby="basic-addon1" name="email" required>
                                </div>
                                 <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-lock"></i></span>
                                    </div>
                                    <input type="password" class="form-control" placeholder="Password" aria-label="Username" aria-describedby="basic-addon1"name="password" required>
                                </div>
                                <div class="row">
                                    <p class="forget-p">Forget Password ?</p>
                                </div>
                                <div class="input-group center mb-3">
                                    <button type="submit" name="login" class="btn btn-success btn-round">SIGN IN</button>
                                </div>    
                            </div>
                            
                        </form>

                        </div>
                        <div class="col-lg-4 col-md-5 box-de">
                            <div class="ditk-inf">
                                <h2 class="w-100">Do Not Have an Account </h2>
                                <p>Create your account by clicking the Signup Button</p>
                                <a href="signup.php">
                                <button type="button" class="btn btn-outline-light">SIGN UP</button>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

<script src="assets/js/jquery-3.2.1.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/script.js"></script>


</html>
