<?php
    if(isset($_POST['subs'])){
        include('dbcon.php');
        
        $email=$_POST['email'];
       
        $qry="INSERT INTO `subsmail`(`email`) VALUES ('$email')";
        $run=mysqli_query($con,$qry);
        if($run==true){
            
            header('location:index.php?msgsent=success');
        }
    }
?>